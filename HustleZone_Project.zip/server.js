const express = require('express');
const cors = require('cors');
const multer = require('multer');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const app = express();
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static('uploads'));

const fs = require('fs');
const uploadDir = './uploads';
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir);
}

const db = new sqlite3.Database('database.db');
db.run(\`CREATE TABLE IF NOT EXISTS jobs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT,
    description TEXT,
    category TEXT
)\`);
db.run(\`CREATE TABLE IF NOT EXISTS applications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    job_id INTEGER,
    name TEXT,
    email TEXT,
    cv TEXT
)\`);
db.run(\`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password TEXT
)\`);

db.get("SELECT * FROM users WHERE username = 'admin'", (err, row) => {
  if (!row) {
    db.run("INSERT INTO users (username, password) VALUES ('admin', 'admin123')");
  }
});

const storage = multer.diskStorage({
  destination: './uploads/',
  filename: (_, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});
const upload = multer({ storage });

app.post('/register', (req, res) => {
  const { username, password } = req.body;
  db.run('INSERT INTO users (username, password) VALUES (?, ?)', [username, password], function (err) {
    if (err) return res.status(400).json({ success: false, message: 'Username already exists' });
    res.json({ success: true });
  });
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  db.get('SELECT * FROM users WHERE username = ? AND password = ?', [username, password], (err, row) => {
    if (err) return res.status(500).json(err);
    if (row) res.json({ success: true });
    else res.status(401).json({ success: false, message: 'Invalid credentials' });
  });
});

app.get('/jobs', (_, res) => {
  db.all('SELECT * FROM jobs', [], (err, rows) => {
    if (err) return res.status(500).json(err);
    res.json(rows);
  });
});

app.post('/jobs', (req, res) => {
  const { title, description, category } = req.body;
  db.run('INSERT INTO jobs (title, description, category) VALUES (?, ?, ?)', [title, description, category],
    function (err) {
      if (err) return res.status(500).json(err);
      res.json({ id: this.lastID });
    });
});

app.put('/jobs/:id', (req, res) => {
  const { title, description, category } = req.body;
  db.run('UPDATE jobs SET title = ?, description = ?, category = ? WHERE id = ?', [title, description, category, req.params.id], function (err) {
    if (err) return res.status(500).json(err);
    res.json({ success: true });
  });
});

app.delete('/jobs/:id', (req, res) => {
  db.run('DELETE FROM jobs WHERE id = ?', [req.params.id], function (err) {
    if (err) return res.status(500).json(err);
    res.json({ success: true });
  });
});

app.post('/apply/:job_id', upload.single('cv'), (req, res) => {
  const { name, email } = req.body;
  const job_id = req.params.job_id;
  const cv = req.file ? req.file.path : '';
  db.run('INSERT INTO applications (job_id, name, email, cv) VALUES (?, ?, ?, ?)', [job_id, name, email, cv],
    function (err) {
      if (err) return res.status(500).json(err);
      res.json({ message: 'Application submitted' });
    });
});

app.get('/applications', (_, res) => {
  db.all('SELECT * FROM applications', [], (err, rows) => {
    if (err) return res.status(500).json(err);
    res.json(rows);
  });
});

app.listen(5000, () => console.log('Server running at http://localhost:5000'));
